﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Tac_anCRUD.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            var list = new List<Tacan>();
            using (var db = new dbsy32Entities1())
            {
                list = db.Tacan.ToList();
            }
                return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Tacan u)
        {
            using (var db = new dbsy32Entities1())
            {
                var newUser = new Tacan();
                newUser.username = u.username;
                newUser.password = u.password;

                db.Tacan.Add(newUser);
                db.SaveChanges();

                TempData["msg"] = $"Added {newUser.username} Successfully!";

            }
                return RedirectToAction("Index");
        }
        public ActionResult Update(int id)
        {
            var u = new Tacan();
            using (var db = new dbsy32Entities1())
            {
                u = db.Tacan.Find(id);
            }
                return View(u);
        }
        [HttpPost]
        public ActionResult Update(Tacan u)
        {
            using (var db = new dbsy32Entities1())
            {

                var newUser = db.Tacan.Find(u.id);
                newUser.username = u.username;
                newUser.password = u.password;

              
                db.SaveChanges();

                TempData["msg"] = $"Updated {newUser.username} Successfully!";

            }
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            var u = new Tacan();
            using (var db = new dbsy32Entities1())
            {
                u = db.Tacan.Find(id);
                db.Tacan.Remove(u);
                db.SaveChanges();

                TempData["msg"] = $"Deleted {u.username} Successfully!";
            }
            return RedirectToAction("Index");
        }
    }
}